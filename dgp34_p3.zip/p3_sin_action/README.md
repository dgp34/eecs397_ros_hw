# p3_sin_action

This package addresses P3:  Create an action service that applies amplitudes and frequencies for a given number of cycles to the sin_commander built in P1.

## How to Run

Use the launch file to start the controller, simulator, commander, and client.  It will prompt for amplitude, frequency, and number of cycles. It assumes proper input.  There is no built-in end input.
