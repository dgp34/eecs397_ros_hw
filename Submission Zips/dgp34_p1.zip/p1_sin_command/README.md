# p1_sin_commander

This package addresses P1:  Create a sin commander that prompts for amplitude and frequency and commands the minimal controller to set appropriate sinusoidal velocities.

## How to Run

Use the launch file to start the controller and simulator.  In a separate terminal, start the sin commander separately using rosrun p1_sin_command sin_command.  It will prompt for an amplitude and frequency.  It assumes proper input.  If the inputs need to be edited, kill and restart the sin commander to input a new combination.
